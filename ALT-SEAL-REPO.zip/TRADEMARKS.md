# Trademark & Usage Policy
ALT-SEAL™, AltmanAI™, DailyPilot™, and PAIHI™ are marks of Altman Family Group, LLC.

- Use ™ until USPTO registration grants ®.
- Do not use the emblem or marks on artifacts that have **not** passed ALT-SEAL™ eligibility.
- Do not alter, recolor, or distort the emblem. Minimum legibility: 8pt equivalent in print.
- Placement: bottom-right trust block near verifier when present; otherwise footer.
- Never imply endorsement beyond the sealed artifact’s scope.
