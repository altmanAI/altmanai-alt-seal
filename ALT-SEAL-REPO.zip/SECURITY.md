# Security Contact
For security and trust concerns related to ALT-SEAL™ or verification flows, contact:
press@altmanfamilygroup.example
