## Summary
-

## Screenshots / Demos
-

## Checklist
- [ ] Content reviewed for legal/brand accuracy
- [ ] SHA-256 and receipt references updated if applicable
