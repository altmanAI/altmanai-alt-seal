---
name: Bug report
about: Report a problem with assets or verifier
title: "[Bug] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of the issue.

**Artifact/URL**
-

**Screenshots**
-

**Environment**
-

**Additional context**
-
