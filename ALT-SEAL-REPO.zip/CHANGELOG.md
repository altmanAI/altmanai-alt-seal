# Changelog
- 2025-10-29 — Initial public release of **ALT-SEAL™** repo with policy v1.0, press assets, and in-browser verifier.
