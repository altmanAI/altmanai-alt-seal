# ALT-SEAL™ Brand Guide (Quick)
**Purpose:** Signal that an artifact is verified for human-centered alignment, transparency, and ethical assistive intent.

**Lockups provided:**
- Square (1080×1080)
- Portrait (1080×1350)
- Story (1080×1920)

**Do:**
- Keep adequate whitespace around the emblem.
- Pair with rights line: `PAIHI™ © Altman Family Group, LLC. All Rights Reserved.`
- Include verification path (URL/QR).

**Don’t:**
- Add drop-shadows, outlines, or rotate/skew the emblem.
- Use on unsealed artifacts.
